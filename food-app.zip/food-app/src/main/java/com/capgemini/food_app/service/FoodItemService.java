package com.capgemini.food_app.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.capgemini.food_app.model.FoodItem;

public interface FoodItemService {

	List<FoodItem> getAllFoodItems();

	FoodItem getFoodItemById(Long id);

	FoodItem updateFoodItem(Long id, FoodItem foodItem);

	FoodItem patchFoodItem(Long id, FoodItem foodItem);

	void deleteFoodItem(Long id);

	List<FoodItem> getFoodItemsForRestaurant(Long restaurantID);
    
    
    
    FoodItem createFoodItemWithImage(String name, String category, Integer price, 
                                    String cuisine, Long restaurantId, MultipartFile file) throws IOException;
    
    
    
      
    List<FoodItem> searchFoodItems(String keyword);
    
    List<FoodItem> getFoodItemsByCuisine(String cuisine);
    
    List<FoodItem> getFoodItemsByCategory(String category);
    

}